'''A collection of functions for my project.'''

def showInstructions():
    """I am using some trinket's RPG code in my code as well as taking 
    inspiration and modification of the code. Here is the link to the code: 
    https://trinket.io/python/d06adeb527 . The instructions have been 
    modified/extended upon, by adding two new commands: use and examine, that 
    both do new things."""
    #This prints the title/main menu of the game
    print('''

Recovering Life 
A game of searching and uncovering the truth about yourself. 

========

Things you can do:
  go [direction] (forward, back, left, right, upstairs/downstairs)
  get [item]
  use [item in inventory]
  examine [something in the room ]
''') 
    
    
