"Recovering Life" by Todd Nguyen
COGS 18

This project is a culmination of about two weeks worth of brainstorming and work. 

The project is a mystery, RPG styled game that seeks to entice players to learn about the character they're playing. 
The game is ultimately beaten wants the phrase: "GAME END." is printed.

The primary objective of this game is to solve the mystery given to you at the beginning of the game. To do this, the 
player would follow the game's directions and use strategic thinking to be able to beat the game. The play will die at least once. 
This is because the game is big on trial and error.

LICENSE...

The code is open to anyone who'd like to use it, build upon it, or change it! However, the story is completely off limits. I ask that
anyone who uses the code, uses it with a different story/purpose. 